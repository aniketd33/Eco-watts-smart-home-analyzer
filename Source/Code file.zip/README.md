
# EcoWatts – Smart Home Energy Analyzer

## Overview
EcoWatts is a Streamlit web application to monitor, visualize, and predict household energy usage.

## How to run
1. Install requirements: `pip install -r requirements.txt`
2. Place `energy_usage_Dataset.csv` in the same folder or upload it from the app.
3. Run the app: `streamlit run app.py`

## Files
- `app.py` : Main Streamlit app
- `charts.py` : Visualization functions
- `model.py` : Simple Linear Regression forecast
- `energy_usage_Dataset.csv` : Your dataset (200 records)
- `requirements.txt` : Python dependencies

## Author
Prepared by: Aniket Dombale
